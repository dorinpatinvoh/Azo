import { Module } from "@nestjs/common";
import { RidesController } from "./rides.controller";
import { RidesService } from "./rides.service";
import { RidesGateway } from "./rides.gateway";
import { WalletModule } from "../wallet/wallet.module";
import { NotificationsModule } from "../notifications/notifications.module";

@Module({
  imports: [WalletModule, NotificationsModule],
  controllers: [RidesController],
  providers: [RidesService, RidesGateway],
})
export class RidesModule {}
